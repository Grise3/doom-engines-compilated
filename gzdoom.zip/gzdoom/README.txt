This binary was compiled as-is with the relevant release tag from the GZDoom repository available at:
https://github.com/ZDoom/gzdoom/

### Important Packages! ###

Please install the following packages for your distro: "libfluidsynth" or "fluidsynth" (or both), "libsdl2", "libgtk-3"

If you are using a GNOME-based desktop (GNOME, Ubuntu, Cinnamon, MATE, etc) please add the "gxmessage" package.

If you are using a KDE-based desktop please add the "kdialog" package.
